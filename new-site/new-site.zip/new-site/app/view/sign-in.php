<?php include(VIEW_HEADER); ?>

<div class="sign-in-container">

  <div class="sign-in">

    <div class="sign-in-box">

      <div class="sign-in-logo"></div>

      <br><br><br><br>

      <form id="sign-in" action="/script/ajax/sign-in.php" method="POST">

        <input name="email" type="email" placeholder="E-mailadres">

        <br><br>

        <input name="password" type="password" placeholder="Wachtwoord">

        <br><br><br><br>

    <!--    <button class="button-sign-in" data-button="sign-in">Login</button> -->
          <input class="button-sign-in"  type="submit" value="Login">
      </form>

      <br><br>

      <!-- <button class="button-sign-up" data-button="sign-in">Maak een account aan</button> -->

    </div>

  </div>

</div>

<?php include(VIEW_FOOTER); ?>
