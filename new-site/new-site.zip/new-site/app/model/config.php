<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$db_host = 'localhost';
$db_name = 'causeffe_db';//'admin_causeffect';
$db_user = 'causeffe_db';//'root';
$db_pass = 'YIm1qz9Xq4_G';//'mysqlcubex2018';

sql::$con = new mysqli($db_host, $db_user, $db_pass, $db_name);

class sql {

    public static $con;

}

if (!sql::$con->set_charset("utf8")) {

  printf("Error loading character set utf8: %s\n", sql::$con->error);
  exit();

}

function response_json($data, $status = 200) {
    	header('Content-type: application/json');
	http_response_code($status);
	echo json_encode($data);
}

?>
